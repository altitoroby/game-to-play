You MUST have pgzero, python and pygame for this to work.
Get pygame from typing this in terminal python3 -m pip install -U pygame --user
To get pgzero here’s a tutorial to do so
In a Terminal window, type
pip install pgzero

then after you have python 3 and pygame AND pgzero in terminal when your get the code in a new file named anything type “pgzrun (python file here)” and MAKE sure you have a space before pgzrun and the file other wise it won’t work.

tell me if it works and if it does then thank you for playing!!!
