HEIGHT = 1200
WIDTH = 1569



from random import randint
apple = Actor("apple")
pinapple = Actor("pinapple")


def draw():
    screen.clear()
    apple.draw()

def place_apple():
    apple.x = randint(10, 800)
    apple.y = randint(10, 600)

def on_mouse_down(pos):
    if apple.collidepoint(pos):
        print("Good shot!!")
        place_apple()
    else:
        print("you missed!")

place_apple()




